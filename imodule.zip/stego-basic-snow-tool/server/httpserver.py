#!/usr/bin/env python3

import os
from http.server import SimpleHTTPRequestHandler, HTTPServer
import cgi

PORT = 8080
ROOT_DIR = "/home/ubuntu"
LOG_FILE = os.path.join(ROOT_DIR, "myhttplogfile.txt")

os.chdir(ROOT_DIR)  # Đặt thư mục gốc phục vụ file tĩnh

class MyHandler(SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/':  # Chấp nhận upload trực tiếp từ đường dẫn gốc
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD': 'POST'}
            )
            if 'file' in form:
                fileitem = form['file']
                if fileitem.filename:
                    filename = os.path.basename(fileitem.filename)
                    filepath = os.path.join(ROOT_DIR, filename)  # Lưu trực tiếp vào /home/ubuntu
                    with open(filepath, 'wb') as f:
                        f.write(fileitem.file.read())
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"Upload successful!\n")
                else:
                    self.send_error(400, "No file uploaded")
            else:
                self.send_error(400, "Missing 'file' field")
        else:
            self.send_error(404, "Invalid path")

    def log_message(self, format, *args):
        with open(LOG_FILE, "a") as log_file:
            log_file.write("%s - - [%s] %s\n" %
                           (self.client_address[0],
                            self.log_date_time_string(),
                            format % args))

httpd = HTTPServer(('', PORT), MyHandler)
print(f"Serving at port {PORT}")
httpd.serve_forever()

